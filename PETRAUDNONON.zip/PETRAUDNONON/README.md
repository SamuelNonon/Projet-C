
Ce programme est un jeu type Tower defense nommé 'DAUPHINE VS ETUDINATS'


Ce programme necessite la librarie SDL2 ainsi que la dependance SDL2_ttf, téléchargeable sur Ubuntu avec la commande ci-dessous :

sudo apt install libsdl2-2.0-0 libsdl2-ttf-2.0-0


Grace au Makefile, pour compiler/executer il suffit de taper dans le terminale 'make'. Si make ne marche pas il faut alors taper la commande manuellement : 

gcc `sdl2-config --cflags --libs`  -o main.exe main.c scr/*.c -Iheaders -W -I/usr/local/include/SDL2 -lSDL2_ttf

puis : ./main.exe

En cas de probleme avec la SDL2, se referer à la page officielle : 
https://doc.ubuntu-fr.org/sdl