#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>

// Fonction pour convertir un fichier PNG en BMP et l'enregistrer dans un autre dossier
void convertir_png_en_bmp(const char *dossier_source, const char *dossier_destination, const char *nom_fichier) {
    // Vérifier si le fichier est un PNG
    if (!strstr(nom_fichier, ".png")) return;

    // Construire le chemin complet du fichier source
    char chemin_source[512];
    snprintf(chemin_source, sizeof(chemin_source), "%s/%s", dossier_source, nom_fichier);

    // Charger l'image PNG
    SDL_Surface *image = IMG_Load(chemin_source);
    if (!image) {
        printf("Erreur chargement %s : %s\n", chemin_source, IMG_GetError());
        return;
    }

    // Construire le chemin du fichier BMP dans le dossier de destination
    char chemin_bmp[512];
    snprintf(chemin_bmp, sizeof(chemin_bmp), "%s/%s.bmp", dossier_destination, strtok(nom_fichier, ".")); // Remplace .png par .bmp

    // Sauvegarder en BMP
    if (SDL_SaveBMP(image, chemin_bmp) != 0) {
        printf("Erreur sauvegarde %s : %s\n", chemin_bmp, SDL_GetError());
    } else {
        printf("Converti : %s -> %s\n", chemin_source, chemin_bmp);
    }

    // Libération mémoire
    SDL_FreeSurface(image);
}

// Fonction pour parcourir un dossier et convertir ses images PNG en BMP dans un autre dossier
void parcourir_dossier(const char *dossier_source, const char *dossier_destination) {
    DIR *dir = opendir(dossier_source);
    if (!dir) {
        printf("Erreur ouverture dossier %s\n", dossier_source);
        return;
    }

    // Créer le dossier de destination s'il n'existe pas
    mkdir(dossier_destination, 0777);

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) { // Vérifie si c'est un fichier
            convertir_png_en_bmp(dossier_source, dossier_destination, entry->d_name);
        }
    }

    closedir(dir);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Utilisation : %s <dossier_source> <dossier_destination>\n", argv[0]);
        return 1;
    }

    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);

    parcourir_dossier(argv[1], argv[2]);

    IMG_Quit();
    SDL_Quit();

    return 0;
}
