#include "jeu.h"


int max_tour(Jeu* jeu) { 
    if (jeu->etudiants == NULL) return 0;
    Etudiant* current = jeu->etudiants;
    int max = 0;
    while (current != NULL) {
        if (current->position>max) {
            max = current->position;
        }
        current = current->next;
    }
    return max;
}

Jeu* creer_jeu(void) {
    Jeu* res = malloc(sizeof(Jeu));
    res->etudiants = NULL;
    res->tourelles = NULL;
    res->effets = NULL;
    res->textures = NULL;
    res->projectiles = NULL;
    res->tour = 0;
    res->cagnotte = 0;
    res->statut = -3;
    res->pause = 0;
    res->etat = 8;
    res->window = NULL;
    res->renderer = NULL;
    res->score = 0;
    res->sauvegarde = 0;
    res->choix_joueur = (int)'T';
    res->niveau = 1;
    res->pseudo = malloc((MAX_LONGUEUR_PSEUDO + 1)*sizeof(char));
    res->pseudo[0] = '\0';
    return res;
}

Etudiant* chercher_etudiant(Jeu* jeu, int ligne, int position) {
    Etudiant* current = jeu->etudiants;
    while (current != NULL) {
        if (current->ligne == ligne && current->position == position && current->position != -10 ) {
            return current;
        }
        current = current->next;
    }
        
    return NULL;
}

Tourelle* chercher_tourelle(Jeu* jeu, int ligne, int position) {
    Tourelle* current = jeu->tourelles;
    while (current != NULL) {
        if (current->ligne == ligne && current->position == position) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

void supprimer_effets(Jeu* jeu) {
    while (jeu->effets != NULL) {supprimer_effet(jeu, jeu->effets);}
    return;
}

void supprimer_etudiants(Jeu* jeu) {
    if (jeu->etudiants == NULL) {return;}
    while (jeu->etudiants != NULL) {jeu->etudiants = supprimer_etudiant(jeu, jeu->etudiants);}
    return;
}

void supprimer_tourelles(Jeu* jeu) {
    if (jeu->tourelles == NULL) {return;}
    while (jeu->tourelles != NULL) jeu->tourelles = supprimer_tourelle(jeu, jeu->tourelles);
    return;
}

void supprimer_projectiles(Jeu* jeu) {
    if (jeu->projectiles == NULL) return;
    while (jeu->projectiles != NULL) {jeu->projectiles = supprimer_projectile(jeu, jeu->projectiles);}
    return;
}

void supprimer_textures(Jeu* jeu) {
    if (jeu->textures == NULL) return;
    while (jeu->textures != NULL) {
        supprimer_texture(jeu, jeu->textures);
    }
    return;

}

void Nouvelles_appartitions(Jeu* jeu) {
    Etudiant* etudiant = jeu->etudiants;
    while (etudiant != NULL) {
        if (etudiant->position == -10 && etudiant->tour == jeu->tour) {
            if (chercher_etudiant(jeu, etudiant->ligne, NUMERO_POSITION_1ER_APPARITION) == NULL && (chercher_tourelle(jeu, etudiant->ligne, NUMERO_POSITION_1ER_APPARITION) == NULL || chercher_tourelle(jeu, etudiant->ligne, NUMERO_POSITION_1ER_APPARITION)->type == 'B')) {
                etudiant->position = NUMERO_POSITION_1ER_APPARITION;
                etudiant->etat = 2;
                etudiant->dx = 100;
            }
            else etudiant->tour += 1;
        }
        etudiant = etudiant->next;
    }

    return;
}


void actualier_prev_next_line_etudiant(Jeu* jeu) {
    Etudiant* etudiant = jeu->etudiants;
    while (etudiant != NULL) {
        actualise_prev_line(jeu, etudiant);
        actualiser_next_line(jeu, etudiant);
        etudiant = etudiant->next;
    }
    return;
}




void demander_tourelle(Jeu* jeu) {
    
    int r = 1;
    while ( r== 1) {
        system("clear");
        afficher_jeu(jeu);
        char *menu[] = {"Placer une nouvelle tourelle", "Lancer la partie"};
        r = Ask_in_Menu(menu, 2);
        clear_lines(4);
        int valide = 0;
        
        while (valide == 0 && r==1) {
            if (jeu->cagnotte < 100) {
            return;
            }
            jeu->cagnotte -= 100;
            int l, p;
            scanf("%d", &l);
            scanf("%d", &p);
            if (l>=1 && l<=7 && p>=1 && p<= MAX_CASE) {
                if (chercher_etudiant(jeu, l, p) != NULL) {
                    clear_lines(4);
                    continue;
                }
                if (chercher_tourelle(jeu, l, p) != NULL) {
                    clear_lines(4);
                    continue;
                }
                ajouter_tourelle(jeu, (int)'T', l, p);
                valide =1;
            }
        }
    }

    return;
}

void actualiser_attaques_etudiants(Jeu* jeu) {
    Etudiant* etudiant = jeu->etudiants;
    while (etudiant != NULL && etudiant->position >-5) {
        for (int i = etudiant->position -1; i>= etudiant->position - etudiant->portee; i--) {
            Tourelle* t = chercher_tourelle(jeu, etudiant->ligne, i);
            if (etudiant->type == 'M') {ajouter_effet(jeu, 'F', etudiant->ligne, i);}
            if (t!= NULL && t->type != 'B' && etudiant->prev_line == NULL) {
                t->pointsDeVie -= etudiant->degats;
                etudiant->etat = 3;
                if (etudiant->type == 'T') {ajouter_effet(jeu, 'E', etudiant->ligne, i);}
                if (t->pointsDeVie <= 0) {ajouter_effet(jeu, (int)'E', t->ligne, t->position) ; supprimer_tourelle(jeu, t);}
            }
        }
        etudiant = etudiant->next;
    }
    return;
}

void actualiser_attaques_tourelles(Jeu* jeu) {
    Tourelle* tourelle = jeu->tourelles;
    while (tourelle != NULL) {
        tourelle_attack(jeu, tourelle);
        tourelle = tourelle->next;
        
    }
    return;
}

void actualiser_positions(Jeu* jeu) {

    Etudiant* courant = jeu->etudiants;
    
    while(courant != NULL && courant->position >-5) {
        actualise_prev_line(jeu, courant);
        
        int j = 0;
        for(int i=1; i<courant->vitesse+1; i++) {
            
            if(courant->type == 'D' && (courant->prev_line == NULL || courant->prev_line->position < courant->position-1) && (chercher_tourelle(jeu, courant->ligne, courant->position-1) == NULL || chercher_tourelle(jeu, courant->ligne, courant->position-1)->type == 'B' || chercher_tourelle(jeu, courant->ligne, courant->position-1)->type == 'M')) {courant->position -= 1; j++; continue;}


            if (chercher_tourelle(jeu, courant->ligne, courant->position) != NULL && chercher_tourelle(jeu, courant->ligne, courant->position)->type == 'B') break; //si sur la place actuelle il y a une bombe
            if (chercher_tourelle(jeu, courant->ligne, courant->position-1) != NULL && chercher_tourelle(jeu, courant->ligne, courant->position-1)->type != 'B') break; //si il y a une tourelle juste devant qui n'est pas une bombe



            if (courant->prev_line == NULL || courant->prev_line->position < courant->position-1) {courant->position -= 1; j++; continue;}
            break;
        }
        
        if (j > 0) {courant->etat = 2; courant->dx = j*X_CONSTANTE;}   
        if (courant->position <= 0) {jeu->statut = 2; return;}
        courant = courant->next;
        
    }

    return;
}


void gestion_event(Jeu* jeu) {


    int x;
    int y;
    SDL_GetMouseState(&x, &y);
    if (x>= 270 && x<= 270+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/T.bmp", 270, 670, 100, 200);}
    if (x>= 380 && x<= 380+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/O.bmp", 380, 670, 100, 200);}
    if (x>= 490 && x<= 490+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/M.bmp", 490, 670, 100, 200);}
    if (x>= 600 && x<= 600+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/L.bmp", 600, 670, 100, 200);}
    if (x>= 710 && x<= 710+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/B.bmp", 710, 670, 100, 200);}
    if (x>= 820 && x<= 820+100 && y>= 870 && y<= 870+100) {afficherImage(jeu, "assets/infos/F.bmp", 820, 670, 100, 200);}



    while (SDL_PollEvent(&(jeu->event))) {
        switch (jeu->event.type) {

                case SDL_QUIT : 
                    jeu->statut = 999;
                    break;
                
                case SDL_WINDOWEVENT : 
                    if (jeu->event.window.event == SDL_WINDOWEVENT_MINIMIZED) {
                        jeu->pause = 1;
                    }
                    break;
                

                case SDL_KEYDOWN :
                    switch (jeu->event.key.keysym.sym){
                        case SDLK_ESCAPE : 
                            if (jeu->pause == 0) {jeu->pause = 1; break;}
                            else if (jeu->pause == 1) {jeu->pause = 0; break;}
                        case SDLK_RETURN : if (jeu->etat == 8 && jeu->statut ==1) {jeu->etat = 9;} break;
                    }
                    break;

                
                case SDL_MOUSEBUTTONDOWN :
                    switch (jeu->event.button.button) {
                        case SDL_BUTTON_LEFT : 

//Jeu statut = -2
                            if (jeu->statut == -2) {
                                if (jeu->event.button.x >= 100 && jeu->event.button.x <= 100+300 && jeu->event.button.y >= 400 && jeu->event.button.y <= 400+100) {
                                    jeu->niveau = 1;
                                    jeu->statut = -1;
                                    break;
                                }
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+300 && jeu->event.button.y >= 400 && jeu->event.button.y <= 400+100) {
                                    jeu->niveau = 2;
                                    jeu->statut = -1;
                                    break;
                                }
                                if (jeu->event.button.x >= 1100 && jeu->event.button.x <= 1100+300 && jeu->event.button.y >= 400 && jeu->event.button.y <= 400+100) {
                                    jeu->niveau = 3;
                                    jeu->statut = -1;
                                    break;
                                }
                                if (jeu->event.button.x >= 350 && jeu->event.button.x <= 350+300 && jeu->event.button.y >= 550 && jeu->event.button.y <= 550+100) {
                                    jeu->niveau = 4;
                                    jeu->statut = -1;
                                    break;
                                }
                                if (jeu->event.button.x >= 850 && jeu->event.button.x <= 850+300 && jeu->event.button.y >= 550 && jeu->event.button.y <= 550+100) {
                                    jeu->niveau = 5;
                                    jeu->statut = -1;
                                    break;
                                }
                            }
//Jeu statut = -1
                            if (jeu->statut == -1) {
                                if (jeu->event.button.x >= 100 && jeu->event.button.x <= 100+300 && jeu->event.button.y >= 400 && jeu->event.button.y <= 400+100) {
                                    jeu->sauvegarde = 0;
                                    jeu->statut = 1;
                                    break;
                                }
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+300 && jeu->event.button.y >= 400 && jeu->event.button.y <= 400+100) {
                                    jeu->statut = 1;
                                    break;
                                }
                                break;
                            }
//Jeu partie en cours
                            if (jeu->statut == 1 && jeu->pause == 0) {


                                if (jeu->event.button.x >= 270 && jeu->event.button.x <= 270+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'T';}
                                if (jeu->event.button.x >= 380 && jeu->event.button.x <= 380+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'O';}
                                if (jeu->event.button.x >= 490 && jeu->event.button.x <= 490+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'M';}
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'L';}
                                if (jeu->event.button.x >= 710 && jeu->event.button.x <= 710+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'B';}
                                if (jeu->event.button.x >= 820 && jeu->event.button.x <= 820+100 && jeu->event.button.y >= 870 && jeu->event.button.y <= 870+100) {jeu->choix_joueur = (int)'F';}




                                //placement des tourelles quand c'est le bon moment
                                if (jeu->etat == 8) {
                                    for (int i=1; i<8; i++) {
                                        for (int j=1; j<MAX_CASE; j++) {
                                            if (jeu->event.button.x >= X_START + (j-1)*X_CONSTANTE && jeu->event.button.x <= X_START + (j-1)*X_CONSTANTE + X_CONSTANTE/2 && jeu->event.button.y >= Y_START + (i-1)*Y_CONSTANTE && jeu->event.button.y <= Y_START + (i-1)*Y_CONSTANTE + Y_CONSTANTE/2) {
                                                if (chercher_etudiant(jeu, i, j) == NULL && chercher_tourelle(jeu, i, j) == NULL) {
                                                    switch (jeu->choix_joueur){
                                                    case 'T':
                                                        if (jeu->cagnotte >= 100) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 100;}
                                                        break;
                                                    
                                                    case 'O':
                                                        if (jeu->cagnotte >= 200) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 200;}
                                                        break;
                                                    
                                                    case 'M':
                                                        if (jeu->cagnotte >= 50) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 50;}
                                                        break;
                                                    case 'L':
                                                        if (jeu->cagnotte >= 400) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 400;}
                                                        break;
                                                    case 'B':
                                                        if (jeu->cagnotte >= 100) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 100;}
                                                        break;
                                                    case 'F':
                                                        if (jeu->cagnotte >= 200) {ajouter_tourelle(jeu, jeu->choix_joueur, i, j); jeu->cagnotte-= 200;}
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (jeu->event.button.x >= 928 && jeu->event.button.x <= 928+280 && jeu->event.button.y >= 866 && jeu->event.button.y <= 866+108) {
                                        jeu->etat = 9;
                                    }

                                }
                            }
// en pause
                            if (jeu->pause == 1) {
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+300 && jeu->event.button.y >= 300 && jeu->event.button.y <= 300+100) {
                                    jeu->pause = 0;
                                }
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+300 && jeu->event.button.y >= 450 && jeu->event.button.y <= 450+100) {
                                    jeu->statut = 998;
                                }
                                if (jeu->event.button.x >= 600 && jeu->event.button.x <= 600+300 && jeu->event.button.y >= 600 && jeu->event.button.y <= 600+100) {
                                    jeu->statut = 999;
                                }
                            }


                            if (jeu->statut == 2 || jeu->statut == 3) {
                                if (jeu->event.button.x >= 800 && jeu->event.button.x <= 800+300 && jeu->event.button.y >= 600 && jeu->event.button.y <= 600+100) {jeu->statut = 999;}
                                if (jeu->event.button.x >= 400 && jeu->event.button.x <= 400+300 && jeu->event.button.y >= 600 && jeu->event.button.y <= 600+100) {jeu->statut = 998;}
                            }
                            
                            break;

                    }
        }
    }
}

