#include <SDL.h>
#include <SDL_ttf.h>
#include <stdio.h>

#define TAILLE_TEXTE 64

void enregistrer_surface(SDL_Surface *surface, char lettre) {
    char nom_fichier[32];
    snprintf(nom_fichier, sizeof(nom_fichier), "font/lettre_%c.bmp", lettre);
    SDL_SaveBMP(surface, nom_fichier);
}

int main() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0 || TTF_Init() < 0) {
        printf("Erreur SDL/TTF: %s\n", SDL_GetError());
        return 1;
    }

    TTF_Font* font = TTF_OpenFont("fonts/2.ttf", 128);
    if (!font) {
        printf("Erreur chargement police: %s\n", TTF_GetError());
        return 1;
    }

    SDL_Color blanc = {255, 255, 255, 255};
    for (char c = ' '; c <= ' '; c++) {
        SDL_Surface *surface = TTF_RenderGlyph_Blended(font, c, blanc);
        if (!surface) continue;
        enregistrer_surface(surface, c);
        SDL_FreeSurface(surface);
    }

    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
    return 0;
}