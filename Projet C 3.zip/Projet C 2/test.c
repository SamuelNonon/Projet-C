

#define LARGEUR_FENETRE 800
#define HAUTEUR_FENETRE 600




#include <SDL.h>
#include <stdio.h>
#include <string.h>


void ecrire_texte(SDL_Renderer *renderer, const char *texte, int taille, int x, int y) {
    int longueur = strlen(texte);
    int espace = taille; // Espacement entre les lettres

    for (int i = 0; i < longueur; i++) {
        char lettre = texte[i];

        // Charger la texture directement dans la fonction
        char chemin[19];
        sprintf(chemin, "font/lettre_%c.bmp", lettre); // Ex: "lettre_A.png"

        SDL_Surface *surface = SDL_LoadBMP(chemin);
        if (!surface) {
            printf("Erreur chargement image %s : %s\n", chemin, SDL_GetError());
            continue;
        }

        SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_FreeSurface(surface);

        int hauteur, largeur;
        SDL_QueryTexture(texture, NULL, NULL, &largeur, &hauteur);

        if (!texture) {
            printf("Erreur création texture %s\n", chemin);
            continue;
        }

        // Position et affichage de la lettre

        SDL_Rect dest = {x, y, largeur, hauteur};
        SDL_RenderCopy(renderer, texture, NULL, &dest);

        x += largeur + espace;

        SDL_DestroyTexture(texture); // Libérer la texture après affichage
    }
    return;
}



int main(int argc, char *argv[]) {
    // Initialisation de SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur lors de l'initialisation de SDL: %s\n", SDL_GetError());
        return 1;
    }

    // Création de la fenêtre
    SDL_Window *window = SDL_CreateWindow("Fenêtre SDL2", 
                                          0, 0, 
                                          LARGEUR_FENETRE, HAUTEUR_FENETRE, 
                                          SDL_WINDOW_SHOWN);
    if (!window) {
        printf("Erreur lors de la création de la fenêtre: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Création du renderer
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        printf("Erreur lors de la création du renderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Couleur de fond (noir)
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    // Définition de la couleur du rectangle (rouge)
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_Rect rect = {LARGEUR_FENETRE / 4, HAUTEUR_FENETRE / 4, LARGEUR_FENETRE / 2, HAUTEUR_FENETRE / 2};
    SDL_RenderFillRect(renderer, &rect);

    // Affichage du rendu
    SDL_RenderPresent(renderer);

    printf("Appuyez sur une touche pour quitter\n");

    // Attendre 5 secondes
    SDL_Delay(5000);

    // Nettoyage
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}