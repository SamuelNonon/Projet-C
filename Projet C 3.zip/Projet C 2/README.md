Pour compiler et executer ce projet une installation de la SDL2 complete est necessaire : 

sudo apt install libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-ttf-2.0-0


En cas de probleme se referer a la page officielle : 
https://doc.ubuntu-fr.org/sdl